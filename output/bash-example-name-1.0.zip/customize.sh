#!/system/bin/sh
# Auto-generated customize.sh script

SKIPUNZIP=1
DEFAULT_PATH="/data/adb/magisk"

extract() {
    local filename=$1
    local dst=$2
    unzip -qo "$ZIPFILE" "$filename" -d "$dst"
}
# Root interface detection
KSUDIR="/data/adb/ksu"
BUSYBOX="$DEFAULT_PATH/busybox"
KSU=false
if [ -d $KSUDIR ]; then
    KSU=true
    DEFAULT_PATH=$KSUDIR
    BUSYBOX="$DEFAULT_PATH/bin/busybox"
fi

# Extract zygisk libraries
isZygisk=false
if $isZygisk; then
    DEVICE_ABI="$(getprop ro.product.cpu.abi)"
    if [ "$DEVICE_ABI" = "arm64-v8a" ] || [ "$DEVICE_ABI" = "armeabi-v7a" ] || [ "$DEVICE_ABI" = "x86_64" ] || [ "$DEVICE_ABI" = "x86" ]; then
        extract "zygisk/$DEVICE_ABI.so" $MODPATH
    else
        abort "Unknown architecture: $DEVICE_ABI"
    fi
fi

# Setup bash environment
INSTALLER="$TMPDIR/installer.sh"

extract "installer.sh" $TMPDIR
extract "bin/bash.xz" $TMPDIR

if [ ! -f "$TMPDIR/bin/bash.xz" ]; then
    abort "Error: required files are not found."
else
    $BUSYBOX xz -d $TMPDIR/bin/bash.xz
fi

# Setting up files permissions
chmod 755 "$TMPDIR/bin/bash" || abort "Couldn't change -> $TMPDIR/bin/bash permission"
chmod +x "$INSTALLER" || abort "Couldn't change -> $INSTALLER permission"

# Setup module environment
export OUTFD ABI API MAGISKBIN NVBASE BOOTMODE MAGISK_VER_CODE MAGISK_VER ZIPFILE MODPATH TMPDIR DEFAULT_PATH KSU ABI32 IS64BIT ARCH BMODID BUSYBOX

# bash executor
bashexe() {
    $TMPDIR/bin/bash "$@"
}

# Finally execute the installer
sed -i "1i\ " "$INSTALLER"
sed -i "1s|.*|#!$TMPDIR/bin/bash|" $INSTALLER
bashexe -c ". $DEFAULT_PATH/util_functions.sh; source $INSTALLER"
